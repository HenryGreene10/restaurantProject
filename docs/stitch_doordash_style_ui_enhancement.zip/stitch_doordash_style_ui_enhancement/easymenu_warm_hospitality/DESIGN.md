---
name: EasyMenu Warm Hospitality
colors:
  surface: '#FFFCF7'
  surface-dim: '#dcdad5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ee'
  surface-container: '#f0ede9'
  surface-container-high: '#ebe8e3'
  surface-container-highest: '#e5e2dd'
  on-surface: '#1c1c19'
  on-surface-variant: '#57423a'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f3f0eb'
  outline: '#8b7269'
  outline-variant: '#dec0b6'
  surface-tint: '#a43d0f'
  primary: '#a13b0d'
  on-primary: '#ffffff'
  primary-container: '#c25325'
  on-primary-container: '#fffdff'
  inverse-primary: '#ffb59a'
  secondary: '#7f5600'
  on-secondary: '#ffffff'
  secondary-container: '#feba43'
  on-secondary-container: '#704b00'
  tertiary: '#b32217'
  on-tertiary: '#ffffff'
  tertiary-container: '#d63c2d'
  on-tertiary-container: '#fffcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#812900'
  secondary-fixed: '#ffddaf'
  secondary-fixed-dim: '#feba43'
  on-secondary-fixed: '#281800'
  on-secondary-fixed-variant: '#614000'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4a8'
  on-tertiary-fixed: '#410000'
  on-tertiary-fixed-variant: '#930303'
  background: '#FAF7F2'
  on-background: '#1c1c19'
  surface-variant: '#e5e2dd'
  surface-muted: '#F3EDE4'
  surface-elevated: '#FFFFFF'
  hero-surface: '#1C1410'
  hero-surface-alt: '#2A1F18'
  on-hero: '#FFF7ED'
  text: '#271C17'
  text-strong: '#1C1410'
  muted: '#745E54'
  border: '#E8DCD1'
  primary-strong: '#B42318'
  accent: '#ECAA34'
  success: '#16A34A'
  danger: '#B91C1C'
typography:
  display-editorial:
    fontFamily: newsreader
    fontSize: 72px
    fontWeight: '400'
    lineHeight: 76px
    letterSpacing: -0.03em
  display-product:
    fontFamily: epilogue
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 54px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: epilogue
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: epilogue
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  title-lg:
    fontFamily: inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.12em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  section: 96px
  container-padding: 24px
  card-padding: 24px
---

## Brand & Style
This system is built for independent restaurants that want to feel polished, warm, and unmistakably owned by the restaurant rather than by a generic marketplace. The overall tone is hospitable and premium without becoming luxurious or cold. It should feel like a clean dining room with good lighting, natural materials, and a confident host.

There are two closely related modes inside the same identity. The product mode, used for storefront, rewards, carts, and admin panels, is light, warm, rounded, and practical. The marketing mode, used for the public landing experience, becomes darker and more editorial, with charcoal hero fields, glow overlays, and stronger serif drama. Both modes must still feel like the same brand family.

The UI should never feel sterile. Warm neutrals, terracotta actions, and amber highlights are the anchors. Depth is soft, not glossy. Interaction feels smooth and modern, but the emotional reference point is hospitality, not fintech or enterprise SaaS.

## Colors
The palette is driven by warm neutrals first, then by a restrained red-orange and amber pairing for emphasis.

- **Background (`#FAF7F2`)** is the default canvas. It should read as parchment or stonewashed paper rather than plain white.
- **Surface (`#FFFCF7`)** is used for cards, admin panels, menu modules, and drawer shells. Surfaces stay slightly lighter than the page so the interface feels layered but soft.
- **Text (`#271C17`)** and **Text Strong (`#1C1410`)** are deep roasted-brown inks, not pure black. This keeps the system warm even at high contrast.
- **Muted (`#745E54`)** handles descriptions, helper text, metadata, and secondary labels.
- **Primary (`#C25325`)** is the main action color for buttons, key highlights, and calls to action. **Primary Strong (`#B42318`)** is the darker marketing variant used when the interface needs a more assertive campaign tone.
- **Accent (`#ECAA34`)** is used sparingly for active category chips, soft glows, and celebratory emphasis. It should support the primary color, not compete with it.
- **Hero Surface (`#1C1410`)** and **Hero Surface Alt (`#2A1F18`)** create the dark landing-page shell. On these backgrounds, text shifts to **On Hero (`#FFF7ED`)**.

Use bright color economically. Most screens should feel neutral first, then activated by a small number of warm accents.

## Typography
Typography uses a deliberate split between product clarity and editorial warmth.

- **Inter** is the operational typeface. It handles body copy, labels, form inputs, prices, metadata, and most admin text. It should feel stable, readable, and contemporary.
- **Bree Serif** is the product headline voice. Use it for menu section titles, storefront hero headlines, rewards balances, and other moments where the interface needs character without losing legibility.
- **DM Serif Display** appears only in the marketing layer, especially the public landing hero. It is more theatrical and should be reserved for large statements.
- **DM Sans** supports the marketing layer for navigation and supporting copy, where a slightly more designed tone is useful.

Headline copy is bold, compact, and visibly serifed. Body copy is generous and calm. Small uppercase labels use wide tracking and semibold weight; they should feel like quiet signage, not loud badges.

## Layout & Spacing
The system runs on an 8px rhythm with generous outer gutters and roomy card interiors.

- Standard horizontal padding is 24px.
- Long-form sections on marketing pages breathe with 96px vertical spacing.
- Product cards and admin panels generally use 24px internal padding, with 16px reserved for denser utility modules.
- Menu and dashboard content prefer clearly separated stacked groups instead of dense, border-heavy tables.

The storefront layout is airy and modular. Category sections are broken apart with large vertical gaps. Menu items use two-column composition on larger screens, balancing text and imagery. The landing page uses fixed-width content rails around 1160px, with a narrower 780px column for explanatory copy.

Whitespace is part of the identity. Leave room around major headings, hero copy, and key actions. Do not collapse the layout into crowded grids unless the screen is explicitly a dense operations view.

## Elevation & Depth
Depth is soft and warm. Most surfaces use rounded cards with light borders and restrained shadows instead of heavy contrast jumps.

- Everyday cards use the `soft` shadow, which separates surfaces without making them feel detached from the page.
- Premium shells such as major storefront panels and larger admin surfaces use the `brand` shadow.
- Overlays and modal drawers use the `modal` shadow and should feel clearly above the page.

The marketing hero is the one place where depth becomes more atmospheric. Dark charcoal surfaces, glow gradients, subtle blur, and translucent borders are appropriate there. Elsewhere, the product should stay grounded and readable.

## Shapes
The shape language is rounded and friendly, but still structured.

- Primary shells and large cards use 24px to 32px corners.
- Inputs and standard utility surfaces use 12px corners.
- Menu photos and compact cards often sit around 18px corners.
- Chips, badges, and primary buttons are usually full-pill shapes.

The system should feel tactile, not geometric. Avoid sharp-cornered blocks unless there is a very specific functional reason.

## Components
Buttons are bold, compact, and easy to hit. The default product button is a warm solid terracotta pill. The storefront add-to-cart button is allowed to use a terracotta-to-amber gradient for extra appetite and energy. Outline buttons inside dark hero areas should stay translucent and understated.

Cards are the dominant structural primitive. They should be light surfaces with quiet borders, warm shadows, and clear internal hierarchy. Menu cards are image-aware and should preserve generous breathing room between title, description, metadata, price, and action.

Category chips are sticky, scrollable, and pill-shaped. Inactive chips should blend into the card layer. Active chips can turn amber and pick up a subtle warm glow.

Inputs and drawers should remain clean and utility-focused. Keep them bright, high-contrast, and operational. The overlay drawer for item customization is the sharpest and most neutral panel in the system; it intentionally feels more focused and task-oriented than the softer outer page.

Status banners and error states should use tinted surfaces rather than harsh fills. Even alerts should stay visually consistent with the warm product shell.

## Do's and Don'ts
- Do let warm neutrals carry most of the page.
- Do use serif typography for high-importance headings and branded statements.
- Do keep major interactive elements rounded and comfortably sized.
- Do use amber as a supporting highlight, not as a second primary brand color.
- Do allow the landing experience to become darker and more editorial than the product shell.
- Don't default to pure white backgrounds and pure black text.
- Don't mix cold blues or generic SaaS gradients into the core experience.
- Don't use hard shadows, hard borders, or tiny radii that make the UI feel severe.
- Don't flood screens with primary color; reserve it for the actions and highlights that matter.